//
//  NoteModel.swift
//  Carnival-Mask
//
//  Created by Luigi Cirillo on 08/02/24.
//

import Foundation
import SwiftData

@available(iOS 17.0, *)
@Model //swiftMacro gives implementations and is needed to define a model for SwiftData
class Note {
    
    var image: Data?
    var id: UUID = UUID()
    var title: String?
    var AR: Bool = false
    
    init(){
        self.image = Data()
        self.title = ""
    }
}
