//
//  File.swift
//
//
//  Created by Luigi Cirillo on 09/02/24.
//

import Foundation
import PencilKit
import RealityKit
import SwiftUI
import ARKit


struct ARRepresentableView: UIViewRepresentable {
    var ArImage: Data?
    @Binding var isPhotoCaptureEnabled: Bool
    
    func makeUIView(context: Context) -> ARView {
        
        if(ArImage != nil) {
            
            let arView = ARView(frame: .zero)
            let anchor = AnchorEntity()
            
            // Create materials for the box
            var material = SimpleMaterial()
            
            // Load the image data and create a CGImage from it
            let ImageActualData = try? PKDrawing(data: ArImage!).image(from: PKDrawing(data: ArImage!).bounds, scale: 1.0).cgImage
            
            
            material.color = .init(tint: .white.withAlphaComponent(0.999),
                                   texture: try! MaterialParameters.Texture(TextureResource.generate(from: ImageActualData!, options: .init(semantic: .hdrColor))))
            
            // Create the box models
            let box = ModelEntity(
                mesh: MeshResource.generateBox(width: 3.0, height: 1.6, depth: 0.009),
                materials: [ material]
            )
             
            // Create an anchor for the camera and attach the box to it
             let cameraAnchor = AnchorEntity(.camera)
             cameraAnchor.addChild(box)
 
            // Add the camera anchor and image anchor to the ARView scene
            arView.scene.addAnchor(cameraAnchor)
            arView.scene.addAnchor(anchor)

            // Set the translation of the box to -4 meters in the z-axis
            box.transform.translation = [0, 0, -4.5]

            return arView
        }
        return ARView()
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {
        if isPhotoCaptureEnabled {
            uiView.snapshot(saveToHDR: false) { image in
                let compressed = UIImage(data: (image?.pngData())!)
                
                UIImageWriteToSavedPhotosAlbum(compressed!, nil, nil, nil)
            }
            isPhotoCaptureEnabled = false
        }
    }
}
