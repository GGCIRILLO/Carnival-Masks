//
//  NoteViewController.swift
//  Carnival-Mask
//
//  Created by Luigi Cirillo on 08/02/24.
//

import Foundation
import SwiftUI
import PencilKit

class NoteViewController: UIViewController {

    // Lazily initialize the PencilKit canvas view with specific configurations.
    lazy var canvas: PKCanvasView = {
        let view = PKCanvasView()
        view.drawingPolicy = .default
        view.minimumZoomScale = 1
        view.maximumZoomScale = 1
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isOpaque = true
        view.backgroundColor = .clear
        
        return view
    }()
    
    // Lazily initialize the PencilKit tool picker and add the view controller as an observer.
    lazy var toolPicker: PKToolPicker = {
        let toolPicker = PKToolPicker()
        toolPicker.addObserver(self)
        toolPicker.colorUserInterfaceStyle = .light
        return toolPicker
    }()
    
    // Data representation of the drawing, initially set to an empty Data object.
    var noteData = Data()
    
    // Closure to notify when the drawing changes (The idea is that an external entity can provide a closure to be executed when the drawing on the canvas changes)
    var noteChanged: (Data) -> Void = {_ in}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(canvas)
        
        NSLayoutConstraint.activate([
            canvas.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            canvas.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            canvas.topAnchor.constraint(equalTo: view.topAnchor),
            canvas.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        canvas.delegate = self

        // Make the canvas the first responder, enabling user interactions.
        canvas.becomeFirstResponder()
        
        // Make the tool picker visible for the canvas and add it as an observer.
        toolPicker.setVisible(true, forFirstResponder: canvas)
        toolPicker.addObserver(canvas)
        
        
        // If there is existing drawing data, attempt to initialize the canvas with it.
        if let note = try? PKDrawing(data: noteData) {
            canvas.drawing = note
        }
    }
}

extension NoteViewController : PKToolPickerObserver, PKCanvasViewDelegate {
    
    // This method is called when the drawing on the canvas changes.
    func canvasViewDrawingDidChange(_ canvasView: PKCanvasView) {
        // Notify the external closure about the change by passing the updated drawing data.
        noteChanged(canvasView.drawing.dataRepresentation())
    }
}
