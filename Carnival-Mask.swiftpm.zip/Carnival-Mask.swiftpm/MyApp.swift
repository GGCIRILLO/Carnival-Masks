import SwiftUI
import SwiftData

@available(iOS 17, *)
@main
struct MyApp: App {
    var body: some Scene {
        let sharedModelContainer: ModelContainer = {
            let schema = Schema([
                Note.self,
            ])
            let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)
            
            do {
                return try ModelContainer(for: schema, configurations: [modelConfiguration])
            } catch {
                fatalError("Could not create ModelContainer: \(error)")
            }
        }()
        WindowGroup {
            ContentView()
                .modelContainer(sharedModelContainer)
                .preferredColorScheme(.light)
        }
    }
}
