//
//  NoteView.swift
//  Carnival-Mask
//
//  Created by Luigi Cirillo on 08/02/24.
//

import SwiftUI
import Foundation
import UIKit

@available(iOS 17.0, *)
struct NoteView: View {
    @Environment(\.modelContext) private var context
    
    var id:UUID?
    @State var data:Data?
    var title:String?
    
    
    var body: some View {
        ZStack{
            Image("mask_outline")
                .resizable()
                .scaledToFit()
                .opacity(0.3)
            NoteRepresentableView(data: data ?? Data(), id: id ?? UUID())
                .navigationTitle(title ?? "Untitled")
                .navigationBarTitleDisplayMode(.inline)
        }        
    }
}
//#Preview {
//    if #available(iOS 17.0, *) {
//        NoteView()
//    } else {
//        // Fallback on earlier versions
//    }
//}
