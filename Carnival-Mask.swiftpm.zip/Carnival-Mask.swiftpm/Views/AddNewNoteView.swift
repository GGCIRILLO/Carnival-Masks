//
//  AddNewNoteView.swift
//  Carnival-Mask
//
//  Created by Luigi Cirillo on 08/02/24.
//

import SwiftUI

@available(iOS 17.0, *)
struct AddNewNoteView: View {
    @Environment(\.modelContext) private var modelContext
    
    // Presentation mode to dismiss the view.
    @Environment(\.dismiss) private var dismiss
    
    // State for storing the canvas title.
    @State private var noteTitle = ""
        
    var body: some View {
        NavigationView {
            Form {
                Section {
                    // Text field for entering the canvas title.
                    TextField("Mask title", text: $noteTitle)
                }
            }
            .navigationViewStyle(StackNavigationViewStyle())
            .navigationTitle(Text("Design a new mask"))
            .navigationBarItems(
                leading: Button(action: {
                    dismiss()
                }, label: {
                    Image(systemName: "xmark")
                }),
                trailing: Button(action: {
                    // Check if the canvas title is not empty.
                    if !noteTitle.isEmpty {
                        // Create a new Drawing entity in the CoreData managed object context.
                        let note = Note()
                        
                        // Set the title and tag of the drawing to the entered canvas title.
                        note.title = noteTitle
                        modelContext.insert(note)
                        
                        do {
                            // Save the new drawing to the CoreData managed object context.
                            try modelContext.save()
                        } catch {
                            // Print an error message if there's an issue with saving.
                            print(error)
                        }
                        
                        // Dismiss the current view and return to the previous view.
                       dismiss()

                    }
                }, label: {
                    Text("Save")
                })
            )
        }
    }
}
