import SwiftUI
import SwiftData


@available(iOS 17.0, *)
struct ContentView: View {
    
    @Environment(\.modelContext) private var modelContext
    @Query private var notes : [Note]
    @State private var showNoteSheet = false
    
    var body: some View {
        NavigationView {
            VStack (alignment: .leading){
                Text("Sketch, color and wear your masks. Just have fun!")
                    .font(.headline)
                    .fontWeight(.regular)
                    .foregroundStyle(.gray)
                    .padding(.horizontal)
                
                // List of drawings with navigation links to DrawingView(open the drawing)
                ScrollView{
                    ForEach(notes) { note in
                        NavigationLink(destination: NoteView(id: note.id, data: note.image, title: note.title)){
                            NoteListView(note: note)
                            }
                    }
                    .padding()
                }
                .navigationTitle("Carnival Mask")
                .toolbar {
                    // Button to show the sheet for adding a new canvas
                    Button(action: {
                        showNoteSheet.toggle()
                    }, label: {
                        Image(systemName: "square.and.pencil")
                    })
                }
                Spacer()
                .sheet(isPresented: $showNoteSheet, content: {
                        AddNewNoteView()
                    })
            }
            .navigationViewStyle(DoubleColumnNavigationViewStyle())
            
            // Placeholder for when no canvas is selected.
            VStack {
                Image(systemName: "scribble.variable")
                    .font(.largeTitle)
                Text("No canvas selected")
                    .font(.title)
            }
        }
    }
}
//
//#Preview {
//    if #available(iOS 17.0, *) {
//        ContentView()
//            .modelContainer(for: Note.self, inMemory: true)
//    } else {
//        // Fallback on earlier versions
//    }
//}

