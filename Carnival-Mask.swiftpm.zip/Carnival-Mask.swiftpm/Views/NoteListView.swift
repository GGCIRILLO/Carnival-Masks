//
//  NoteListView.swift
//  Carnival-Mask
//
//  Created by Luigi Cirillo on 08/02/24.
//

import SwiftUI
import Foundation

@available(iOS 17.0, *)
struct NoteListView: View {
    
    let note: Note
    
    @Environment(\.modelContext) private var modelContext
    @State private var isPhotoCaptureEnabled = false
    @State private var showArView = false
    
    
    var body: some View {
        
        ZStack{
            RoundedRectangle(cornerRadius: 10)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 60)
                .shadow(radius: 2)
            HStack {
                Text(note.title ?? "Untitled")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundStyle(.black)
                Spacer()
                Image(systemName: "chevron.right")
            }
            
            .padding()
        }
        .contextMenu {
            Button(action: {
                showArView.toggle()
            }, label: {
                HStack {
                    Text("3D View")
                    Image(systemName: "cube.transparent")
                }
            })
            .disabled(note.image?.isEmpty ?? true)
            
            Button(action: {
                modelContext.delete(note)
            }, label: {
                HStack{
                    Text("Delete note")
                    Image(systemName: "trash")
                }
                .foregroundStyle(.red)
            })
        }
        .sheet(isPresented: $showArView, content: {
            ZStack(alignment: .bottom){
                ARRepresentableView(ArImage: note.image, isPhotoCaptureEnabled: $isPhotoCaptureEnabled)
                    .ignoresSafeArea()
                
                Button(action: {
                    isPhotoCaptureEnabled.toggle()
                }, label: {
                    ZStack{
                        Circle()
                            .fill(Color.white)
                            .frame(width: 55, height: 55)
                        Circle()
                            .stroke(.black, lineWidth: 5)
                            .fill(.white)
                            .frame(width: 40, height: 40)
                    }
                    .padding()
                })
            }
        })
    }
}
